<?php exit();?>
{		
    "CorpId"     : "wwd6caf1ae7fe4633e",
    "TxlSecret"  : "__PPxmJi1XEMlFjVSzD4wCG4hOwMccoxavX7czHRyEw",
    "AppsConfig" : [
        { 
            "AppDesc": "应用1的描述",               
            "AgentId": 1000001,
            "Secret" : "应用1的密钥，在管理后台查看",
            "Token"  : "应用1回调模式的Token，在应用的回调模式里面设置",
            "EncodingAESKey":"应用1回调模式的加密串，在应用的回调模式里面设置"            
        },
        { 
            "AppDesc": "应用2的描述",               
            "AgentId": 1000002,
            "Secret" : "应用2的密钥，在管理后台查看",
            "Token"  : "应用2回调模式的Token，在应用的回调模式里面设置",
            "EncodingAESKey":"应用2回调模式的加密串，在应用的回调模式里面设置"            
        }
    ]
}
