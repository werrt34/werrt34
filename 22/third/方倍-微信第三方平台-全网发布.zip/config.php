<?php

define("AppID",             "wx2ae3853dda623211");
define("AppSecret",         "df8a05425d4ba95405fb1b048704373e");

define("Token",             "weixin");
define("EncodingAESKey",    "abcdefghijklmnopqrstuvwxyz0123456789ABCDEFG");

?>