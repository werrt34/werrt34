<?php

define("AppID",             "wx2c864d9d0837f953");
define("AppSecret",         "9e77e492f3f320afb4b54ef1731159d8");

define("Token",             "weixin");
define("EncodingAESKey",    "abcdefghijklmnopqrstuvwxyz0123456789ABCDEFG");

?>